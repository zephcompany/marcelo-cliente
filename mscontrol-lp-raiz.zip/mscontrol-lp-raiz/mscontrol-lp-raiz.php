<?php
/**
 * Plugin Name: MS Control LP na raiz (instalador temporário)
 * Description: Copia a landing page do MS Control para a raiz do site e faz a página inicial abrir a LP. Pode ser apagado depois de ativar uma vez; a página continua no ar.
 * Version: 1.0
 * Author: Zeph Company
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

register_activation_hook( __FILE__, function () {
	$root   = rtrim( ABSPATH, '/' );
	$marker = $root . '/.mscontrol-lp';
	$ours   = array( 'index.html', 'css', 'js', 'img', 'fonts', 'vendor', 'painel' );
	if ( ! file_exists( $marker ) ) {
		foreach ( $ours as $p ) {
			if ( file_exists( $root . '/' . $p ) ) {
				wp_die( 'Já existe "' . esc_html( $p ) . '" na raiz do site e não foi criado por este instalador. Nada foi alterado.' );
			}
		}
	}
	if ( ! class_exists( 'ZipArchive' ) ) { wp_die( 'ZipArchive indisponível no servidor. Nada foi alterado.' ); }
	$zip = new ZipArchive();
	if ( true !== $zip->open( __DIR__ . '/lp.zip' ) ) { wp_die( 'Não foi possível abrir o pacote da página. Nada foi alterado.' ); }
	$zip->extractTo( $root );
	$zip->close();
	file_put_contents( $marker, 'MS Control LP ' . gmdate( 'c' ) );
	// a raiz abre o index.html da LP; o resto do WordPress (wp-admin etc.) segue igual
	$ht  = $root . '/.htaccess';
	$cur = file_exists( $ht ) ? file_get_contents( $ht ) : '';
	if ( false === strpos( $cur, '# BEGIN MS Control LP' ) ) {
		$block = "# BEGIN MS Control LP\nDirectoryIndex index.html index.php\n# END MS Control LP\n\n";
		file_put_contents( $ht, $block . $cur );
	}
	if ( function_exists( 'do_action' ) ) { do_action( 'litespeed_purge_all' ); }
} );
