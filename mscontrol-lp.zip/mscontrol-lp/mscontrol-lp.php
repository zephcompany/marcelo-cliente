<?php
/**
 * Plugin Name: MS Control · Landing page
 * Description: Mostra a landing page do MS Control na página inicial do site. Os arquivos ficam em /ms-lp. Desativar este plugin volta a página inicial padrão do WordPress.
 * Version: 1.0
 * Author: Zeph Company
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'MSLP_DIR', ABSPATH . 'ms-lp' );

function mslp_install() {
	if ( ! class_exists( 'ZipArchive' ) ) { return; }
	$zip_file = __DIR__ . '/lp.zip';
	if ( ! file_exists( $zip_file ) ) { return; }
	wp_mkdir_p( MSLP_DIR );
	$zip = new ZipArchive();
	if ( true === $zip->open( $zip_file ) ) {
		$zip->extractTo( MSLP_DIR );
		$zip->close();
		file_put_contents( MSLP_DIR . '/.versao', md5_file( $zip_file ) );
	}
}
register_activation_hook( __FILE__, 'mslp_install' );

// se o pacote mudar (plugin atualizado), extrai de novo
add_action( 'admin_init', function () {
	$zip_file = __DIR__ . '/lp.zip';
	$v = MSLP_DIR . '/.versao';
	if ( file_exists( $zip_file ) && ( ! file_exists( $v ) || trim( file_get_contents( $v ) ) !== md5_file( $zip_file ) ) ) { mslp_install(); }
} );

add_action( 'template_redirect', function () {
	if ( is_admin() || ! ( is_front_page() || is_home() ) ) { return; }
	if ( isset( $_GET['s'] ) || isset( $_GET['p'] ) || isset( $_GET['page_id'] ) ) { return; }
	$file = MSLP_DIR . '/index.html';
	if ( ! file_exists( $file ) ) { return; }
	$html = file_get_contents( $file );
	$base = esc_url( home_url( '/ms-lp/' ) );
	// caminhos relativos (css/, js/, img/...) passam a apontar para /ms-lp/
	$html = preg_replace( '/\b(src|href|srcset|poster)="(?!https?:|\/\/|\/|#|data:|mailto:|tel:)((?:css|js|img|fonts|vendor|painel)\/[^"]*)"/i', '$1="' . $base . '$2"', $html );
	$html = preg_replace( '/<head([^>]*)>/i', '<head$1><script>window.MSLP_BASE=' . wp_json_encode( $base ) . ';</script>', $html, 1 );
	if ( ! headers_sent() ) {
		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'Cache-Control: public, max-age=300' );
	}
	echo $html; // phpcs:ignore
	exit;
}, 0 );
