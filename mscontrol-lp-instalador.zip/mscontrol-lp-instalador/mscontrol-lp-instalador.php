<?php
/**
 * Plugin Name: MS Control LP (instalador temporário)
 * Description: Copia a landing page do MS Control para a pasta /appmscontrol do site. Pode ser apagado depois de ativar uma vez; a página continua no ar.
 * Version: 1.0
 * Author: Zeph Company
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

register_activation_hook( __FILE__, function () {
	$dest   = ABSPATH . 'appmscontrol';
	$marker = $dest . '/.mscontrol-lp';
	// só escreve se a pasta não existe ou se foi criada por este instalador
	if ( file_exists( $dest ) && ! file_exists( $marker ) ) {
		wp_die( 'A pasta /appmscontrol já existe e não foi criada por este instalador. Nada foi alterado.' );
	}
	if ( ! class_exists( 'ZipArchive' ) ) {
		wp_die( 'ZipArchive indisponível no servidor. Nada foi alterado.' );
	}
	wp_mkdir_p( $dest );
	$zip = new ZipArchive();
	if ( true !== $zip->open( __DIR__ . '/lp.zip' ) ) {
		wp_die( 'Não foi possível abrir o pacote da página. Nada foi alterado.' );
	}
	$zip->extractTo( $dest );
	$zip->close();
	file_put_contents( $marker, 'MS Control LP ' . gmdate( 'c' ) );
} );
