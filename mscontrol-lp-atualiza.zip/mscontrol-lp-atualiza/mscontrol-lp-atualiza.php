<?php
/**
 * Plugin Name: MS Control LP (atualização temporária)
 * Description: Atualiza o index.html da landing page do MS Control (preloader em toda visita). Só troca o arquivo se ele já for a LP do MS Control. Pode ser apagado depois de ativar.
 * Version: 1.0
 * Author: Zeph Company
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
register_activation_hook( __FILE__, function () {
	$new = __DIR__ . '/lp-index.html';
	$done = array();
	foreach ( array( ABSPATH . 'index.html', ABSPATH . 'appmscontrol/index.html' ) as $f ) {
		if ( file_exists( $f ) && false !== strpos( (string) file_get_contents( $f ), 'MS Control · Sua operação inteira' ) ) {
			copy( $f, $f . '.bak' );
			copy( $new, $f );
			$done[] = $f;
		}
	}
	update_option( 'mscontrol_lp_atualiza', implode( ',', $done ) );
} );
