<?php
/**
 * Plugin Name: MS Control · LP na página inicial
 * Description: Mostra a landing page do MS Control (arquivo index.html da raiz do site) na página inicial. Desativar volta a página inicial padrão do WordPress. Não apagar enquanto a LP estiver no ar.
 * Version: 1.0
 * Author: Zeph Company
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'template_redirect', function () {
	if ( is_admin() || ! ( is_front_page() || is_home() ) ) { return; }
	if ( isset( $_GET['s'] ) || isset( $_GET['p'] ) || isset( $_GET['page_id'] ) || isset( $_GET['preview'] ) ) { return; }
	$file = ABSPATH . 'index.html';
	if ( ! is_readable( $file ) ) { return; }
	if ( ! headers_sent() ) {
		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
	}
	readfile( $file );
	exit;
}, 0 );

// ao ativar, limpa o cache do WP Rocket para a página inicial nova aparecer na hora
register_activation_hook( __FILE__, function () {
	if ( function_exists( 'rocket_clean_domain' ) ) { rocket_clean_domain(); }
} );
